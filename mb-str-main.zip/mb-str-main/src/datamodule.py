
import pytorch_lightning as pl
from typing import List, Union
from src.datasets import dataset_factory
from src.dataloaders import RecDataloader

class RecDataModule(pl.LightningDataModule):
    def __init__(
        self,
        dataset_code: str = None, #数据集code
        target_behavior: str = None, #目标行为
        multi_behavior: Union[bool, List] = None, #是否考虑多行为
        min_uc: int = None, #最小用户计数 过滤掉用户交互项较少的用户
        k:int=None,
        num_items: int = None, #数据集中的项目数量
        max_len: int = None, #一个用户交互项序列的最大长度
        mask_prob: float = None, #掩码概率
        num_workers: int = None, #数据加载时使用的进程数
        val_negative_sampler_code: str = None, #验证集负采样器的代码或标识符
        val_negative_sample_size: int = None, #验证集负采样的样本大小。
        train_batch_size: int = None, #训练集和验证集的批次大小。
        val_batch_size: int = None,
        predict_only_target: bool = None, #是否仅预测目标行为。
    ):
        super().__init__()
        self.dataset_code = dataset_code
        self.min_uc = min_uc
        self.target_behavior = target_behavior
        self.multi_behavior = multi_behavior
        self.num_items = num_items
        self.max_len = max_len
        self.mask_prob = mask_prob
        self.num_workers = num_workers
        self.val_negative_sampler_code = val_negative_sampler_code
        self.val_negative_sample_size = val_negative_sample_size
        self.train_batch_size = train_batch_size
        self.val_batch_size = val_batch_size
        self.predict_only_target = predict_only_target

    def prepare_data(self):
        # 下载和预处理数据
        # 这里它调用了dataset_factory函数来准备数据集
        # download, split, etc...
        # only called on 1 GPU/TPU in distributed
        dataset_factory(
            self.dataset_code,
            self.target_behavior,
            self.multi_behavior,
            self.min_uc,
            )

    # 设置数据集的分配（例如，训练集、验证集和测试集的划分
    def setup(self, stage):
        # make assignments here (val/train/test split)
        # called on every process in DDP
        self.dataset = dataset_factory(
            self.dataset_code,
            self.target_behavior,
            self.multi_behavior,
            self.min_uc,
            )

        # 创建了一个RecDataloader对象，接受多个参数，用于加载和预处理数据
        self.dataloader = RecDataloader(
            self.dataset,
            self.max_len,
            self.mask_prob,
            self.num_items,
            self.num_workers,
            self.val_negative_sampler_code,
            self.val_negative_sample_size,
            self.train_batch_size,
            self.val_batch_size,
            self.predict_only_target,
        )

    def train_dataloader(self):
        return self.dataloader.get_train_loader()
    def val_dataloader(self):
        return self.dataloader.get_val_loader()

class RecDataModuleNeg(pl.LightningDataModule):
    def __init__(
        self,
        dataset_code: str = None,
        target_behavior: str = None,
        multi_behavior: bool = None,
        min_uc: int = None,
        num_items: int = None,
        max_len: int = None,
        mask_prob: float = None,
        num_workers: int = None,
        train_negative_sampler_code: str = None,
        train_negative_sample_size: int = None,
        val_negative_sampler_code: str = None,
        val_negative_sample_size: int = None,
        train_batch_size: int = None,
        val_batch_size: int = None,
        predict_only_target: bool = None,
    ):
        super().__init__()
        self.dataset_code = dataset_code
        self.min_uc = min_uc
        self.target_behavior = target_behavior
        self.multi_behavior = multi_behavior
        self.num_items = num_items
        self.max_len = max_len
        self.mask_prob = mask_prob
        self.num_workers = num_workers
        self.train_negative_sampler_code = train_negative_sampler_code
        self.train_negative_sample_size = train_negative_sample_size
        self.val_negative_sampler_code = val_negative_sampler_code
        self.val_negative_sample_size = val_negative_sample_size
        self.train_batch_size = train_batch_size
        self.val_batch_size = val_batch_size
        self.predict_only_target = predict_only_target

    def prepare_data(self):
        # download, split, etc...
        # only called on 1 GPU/TPU in distributed
        dataset_factory(
            self.dataset_code,
            self.target_behavior,
            self.multi_behavior,
            self.min_uc,
            )

    def setup(self, stage):
        # make assignments here (val/train/test split)
        # called on every process in DDP
        self.dataset = dataset_factory(
            self.dataset_code,
            self.target_behavior,
            self.multi_behavior,
            self.min_uc,
            )
    
        self.dataloader = RecDataloaderNeg(
            self.dataset,
            self.max_len,
            self.mask_prob,
            self.num_items,
            self.num_workers,
            self.train_negative_sampler_code,
            self.train_negative_sample_size,
            self.val_negative_sampler_code,
            self.val_negative_sample_size,
            self.train_batch_size,
            self.val_batch_size,
            self.predict_only_target,
        )

    def train_dataloader(self):
        return self.dataloader.get_train_loader()
    def val_dataloader(self):
        return self.dataloader.get_val_loader()