

from src.dataloaders.base import AbstractDataloader

import torch
import numpy as np
import torch.utils.data as data_utils
# 该类继承自AbstractDataloader base.py中的

# RecDataloader接收一系列参数，
# 包括从父类AbstractDataloader继承的参数
# （如dataset、val_negative_sampler_code、val_negative_sample_size）以及它自身特有的参数。
# 它首先调用父类的__init__方法来初始化父类中的属性和方法。
"""
RecDataloader类提供了从原始数据集中创建训练集和验证集 数据加载器的方法。
这些加载器可以在模型的训练和验证阶段使用。该类通过封装数据集的创建和加载过程，使得模型训练和验证更加便捷和高效。
同时，它也提供了灵活的配置选项，如批次大小、序列长度和掩码概率等，以适应不同的推荐系统任务和数据集。
"""

class RecDataloader(AbstractDataloader):
    def __init__(
            self,
            dataset,
            seg_len,
            mask_prob,
            num_items,
            k,
            num_workers,
            val_negative_sampler_code,
            val_negative_sample_size,
            train_batch_size,
            val_batch_size,
            predict_only_target=False,
        ):
        super().__init__(dataset,
            val_negative_sampler_code,
            val_negative_sample_size)
        # # target_code：根据bmap（行为映射）获取'buy'或'pos'对应的编码，这可能是用于标识目标行为的编码。
        # # seg_len：序列长度，可能用于处理时间序列数据或序列模型。
        # # mask_prob：掩码概率，可能用于数据增强或模型训练中的某些随机过程。
        # # num_items：物品的数量。
        # # num_workers：数据加载时使用的进程数，这可以加速数据加载。
        # # train_batch_size 和 val_batch_size：分别用于训练集和验证集的数据批次大小。
        # # predict_only_target：一个布尔值，可能用于控制是否仅预测目标行为。
        self.target_code = self.bmap.get('buy') if self.bmap.get('buy') else self.bmap.get('pos')
        self.seg_len = seg_len
        self.mask_prob = mask_prob
        self.num_items = num_items
        self.num_workers = num_workers
        self.k=k
        self.train_batch_size = train_batch_size
        self.val_batch_size = val_batch_size
        self.predict_only_target = predict_only_target

    # 获取训练集的数据加载器。
    # 它首先调用_get_train_dataset方法来获取一个训练数据集对象，
    # 然后使用data_utils.DataLoader（这个工具可能是在其他地方定义的）来创建一个数据加载器，
    # 该加载器将用于在训练过程中迭代数据。
    def get_train_loader(self):
        dataset = self._get_train_dataset()
        dataloader = data_utils.DataLoader(dataset, batch_size=self.train_batch_size,
                                           shuffle=True, num_workers=self.num_workers)
        return dataloader

    # 这是一个私有方法（由下划线前缀指示）
    # 用于创建训练数据集。
    # 它接收从初始化方法中设置的一些参数，并使用它们来创建一个RecTrainDataset对象。
    # RecTrainDataset可能是一个自定义的数据集类，用于处理训练数据的特定格式和预处理。
    def _get_train_dataset(self):
        dataset = RecTrainDataset(self.train, self.train_b, self.seg_len, self.mask_prob, self.num_items, self.k, self.target_code, self.predict_only_target)
        return dataset

    # 这个方法与get_train_loader类似，但它用于获取验证集的数据加载器。
    # 它调用_get_eval_dataset方法来获取验证数据集，并使用data_utils.DataLoader来创建数据加载器。
    def get_val_loader(self):
        dataset = self._get_eval_dataset()
        dataloader = data_utils.DataLoader(dataset, batch_size=self.val_batch_size,
                                           shuffle=False, num_workers=self.num_workers)
        return dataloader

    # 也是一个私有方法，用于创建验证数据集。它接收多个参数，并使用它们来创建一个RecEvalDataset对象。
    # RecEvalDataset可能是另一个自定义的数据集类，用于处理验证数据的特定格式和预处理。
    def _get_eval_dataset(self):
        dataset = RecEvalDataset(self.train, self.train_b, self.val, self.val_b, self.val_num, self.seg_len, self.num_items,self.k, self.target_code, self.val_negative_samples)
        return dataset

# RecTrainDataset的类，该类继承自data_utils.Dataset。
# RecTrainDataset被设计为用于处理推荐系统的训练数据集
class RecTrainDataset(data_utils.Dataset):
    def __init__(self, u2seq, u2b, max_len, mask_prob, num_items, k, target_code, predict_only_target):
        self.u2seq = u2seq
        self.u2b = u2b
        # 可能是两个字典，分别映射用户ID到他们的序列（可能是行为序列）和相应的行为类型。
        self.users = sorted(self.u2seq.keys())
        # 初始化方法还定义了一个users列表，该列表包含u2seq字典中所有的用户ID，并且已经排序。
        self.max_len = max_len
        self.mask_prob = mask_prob
        self.num_items = num_items
        self.k=k
        self.target_code = target_code
        self.predict_only_target = predict_only_target

    # 这个方法返回数据集中的用户数量
    def __len__(self):
        return len(self.users)

    # 这个方法允许我们通过索引访问数据集中的单个样本。
    # 它接收一个index参数，并返回与该索引对应的用户的数据。
    #
    # 首先，根据索引获取用户ID、序列和相应的行为类型。
    # 然后，对于序列中的每个元素，根据掩码概率和predict_only_target参数来决定是否对该元素进行掩码。
    # 掩码操作会将元素替换为一个特殊的物品ID（self.num_items+1），并将原始物品ID作为标签保存起来。

    def __getitem__(self, index):
        user = self.users[index]
        seq = self.u2seq[user]
        b_seq = self.u2b[user]

        tokens = []
        behaviors = []
        labels = []
        for s,b in zip(seq, b_seq):
            prob = np.random.rand()
            # * `prob < self.mask_prob`：如果生成的随机概率小于 `mask_prob`，则可能会执行遮罩操作。
            # * `not self.predict_only_target`：如果 `predict_only_target` 属性为 `False`，则不论 `b` 的值如何，都可能会执行遮罩操作。
            # 如果上述两个条件都满足，则执行以下操作：
            if prob < self.mask_prob and not self.predict_only_target:
                tokens.append(self.num_items+1)
                labels.append(s)
            elif prob < self.mask_prob and self.predict_only_target and b == self.target_code:
                tokens.append(self.num_items+1)
                labels.append(s)
            else:
                # 如果上述条件都不满足，那么原始的 s 值会被添加到 tokens 列表中，
                # 并且 labels 列表会添加一个 0，表示这个元素没有被遮罩，并且不需要作为预测目标。
                tokens.append(s)
                labels.append(0)
            behaviors.append(b)
        #     不论是否执行遮罩操作，b（来自 b_seq 的元素）总是被添加到 behaviors 列表中。


        # 接下来，根据序列的长度和max_len参数来决定是否需要对序列进行截断或填充。
        # 如果序列长度小于等于max_len，则直接取序列的最后max_len个元素；
        # 否则，随机选择序列的一个起始位置，并取长度为max_len的子序列。
        # 最后，对截断或填充后的序列、标签和行为类型进行打包，并返回包含这些数据的字典。

        if len(tokens) <= self.max_len or np.random.rand()<0.8:
        # if len(tokens) <= self.max_len:
        # if True:
            tokens = tokens[-self.max_len:]
            labels = labels[-self.max_len:]
            behaviors = behaviors[-self.max_len:]

            padding_len = self.max_len - len(tokens)

            tokens = [0] * padding_len + tokens
            labels = [0] * padding_len + labels
            behaviors = [0] * padding_len + behaviors
        else:
            begin_idx = np.random.randint(0, len(tokens)-self.max_len+1)
            tokens = tokens[begin_idx:begin_idx+self.max_len]
            labels = labels[begin_idx:begin_idx+self.max_len]
            behaviors = behaviors[begin_idx:begin_idx+self.max_len]

        return {
            'input_ids':torch.LongTensor(tokens),
            'labels':torch.LongTensor(labels),
            'behaviors':torch.LongTensor(behaviors)
        }


# 定义了一个名为RecEvalDataset的类，它用于处理推荐系统的验证数据集
class RecEvalDataset(data_utils.Dataset):
    def __init__(self, u2seq, u2b, u2answer, u2ab, val_num, max_len, num_items, k,target_code, negative_samples):
        self.u2seq = u2seq
        self.u2b = u2b
        # u2answer：一个字典，映射用户ID到他们的正确答案或目标物品。
        self.u2answer = u2answer
        # 排序
        self.users = sorted(self.u2answer.keys())
        self.u2ab = u2ab
        # val_num：用于验证的数据集中的样本数量。
        self.val_num = val_num
        self.max_len = max_len
        # 一个字典，映射用户ID到他们的负样本列表。
        self.negative_samples = negative_samples
        self.num_items = num_items
        self.k =k
        # 目标行为的编码。
        self.target_code = target_code

    # 这个方法返回验证数据集中的样本数量，即val_num。
    def __len__(self):
        return self.val_num

    # 这个方法允许我们通过索引访问验证数据集中的单个样本。
    # 它接收一个index参数，并返回与该索引对应的用户的数据。

    # 首先，根据索引获取用户ID、行为序列、正确答案和负样本。
    # 然后，将正确答案和负样本合并为一个候选物品列表，并创建一个标签列表，其中正确答案的标签为1，负样本的标签为0。
    # 接下来，对行为序列进行处理。
    # 首先，在序列末尾添加一个特殊的物品ID（self.num_items + 1），
    # 然后取序列的最后max_len个元素。
    # 同时，对行为类型序列seq_b进行处理，将u2b和u2ab中对应的序列合并，并取最后max_len个元素。
    # 之后，根据序列的实际长度和max_len参数计算填充长度，并使用0对序列和行为类型序列进行填充，
    # 以确保它们的长度都为max_len。
    # 最后，将处理后的序列、候选物品列表、标签和行为类型序列打包成一个字典，并返回该字典。
    def __getitem__(self, index):
        user = self.users[index]
        seq = self.u2seq[user]
        answer = self.u2answer[user]
        negs = self.negative_samples[user]

        candidates = answer + negs
        labels = [1] * len(answer) + [0] * len(negs)

        seq = seq + [self.num_items + 1]
        seq = seq[-self.max_len:]
        seq_b = self.u2b[user] + self.u2ab[user]
        seq_b = seq_b[-self.max_len:]
        padding_len = self.max_len - len(seq)
        seq = [0] * padding_len + seq
        seq_b = [0] * padding_len + seq_b

        return {
            'input_ids':torch.LongTensor(seq),
            'candidates':torch.LongTensor(candidates), 
            'labels':torch.LongTensor(labels),
            'behaviors': torch.LongTensor(seq_b)
        }

    # RecEvalDataset类用于处理推荐系统的验证数据集，特别是那些涉及到用户行为序列、正确答案和负样本的数据。
    # 它允许用户根据最大长度参数对序列进行截断和填充，并返回包含序列、候选物品、标签和行为类型的字典。
    # 这个类可以用于验证和评估基于序列的推荐模型的性能。