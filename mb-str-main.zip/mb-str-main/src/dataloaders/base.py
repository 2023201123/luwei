
from src.dataloaders.negative_samplers import negative_sampler_factory

from abc import *

"用于处理数据集的加载和预处理"
# metaclass=ABCMeta，表明它定义了一个抽象基类，其中的某些方法需要在派生类中被具体实现。

#   val_negative_sampler_code,  一个代码或标识符，用于指定验证集负样本采样的策略。
#     val_negative_sample_size ,验证集负样本的数量
# save_folder = dataset._get_preprocessed_folder_path(),获取预处理数据的文件夹路径

# 通过调用dataset.load_dataset()加载数据集，
# 并提取出训练集、验证集、训练集B、验证集B、验证集数量、用户映射、物品映射和行为映射。
class AbstractDataloader(metaclass=ABCMeta):
    def __init__(self,
            dataset,
            val_negative_sampler_code,
            val_negative_sample_size
            ):
        save_folder = dataset._get_preprocessed_folder_path()
        dataset = dataset.load_dataset()
        self.train = dataset['train']
        self.val = dataset['val']
        self.train_b = dataset['train_b']
        self.val_b = dataset['val_b']
        self.val_num = dataset['val_num']
        self.umap = dataset['umap']
        self.smap = dataset['smap']
        self.bmap = dataset['bmap']

        self.user_count = len(self.umap)
        self.item_count = len(self.smap)
        self.behavior_count = len(self.bmap)

        # 根据提供的val_negative_sampler_code和其他相关参数，通过调用negative_sampler_factory函数
        # 创建一个负样本采样器对象。最后，使用这个采样器对象获取验证集的负样本，
        # 并保存在self.val_negative_samples中。

        val_negative_sampler = negative_sampler_factory(val_negative_sampler_code, self.train, self.val,
                                                         self.user_count, self.item_count,
                                                         val_negative_sample_size,
                                                         save_folder)
        self.val_negative_samples = val_negative_sampler.get_negative_samples()

    # 这个方法需要在派生类中实现，用于获取训练集的数据加载器（DataLoader）。
    @abstractmethod
    def get_train_loader(self):
        pass


    # 这个方法也需要在派生类中实现，用于获取验证集的数据加载器。
    @abstractmethod
    def get_val_loader(self):
        pass