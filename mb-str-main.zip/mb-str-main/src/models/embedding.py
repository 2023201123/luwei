
from torch import nn as nn
"这段代码提供了一个基本的框架来生成位置嵌入，但可能需要根据具体的应用场景进行一些调整和优化。"
# 这个模型用于为序列中的每个位置生成一个嵌入向量，通常用于Transformer模型中的位置编码。
"位置嵌入embedding"
class PositionalEmbedding(nn.Module):
    
    def __init__(self, max_len, d_model):
        super().__init__()
        # 序列的最大长度。 嵌入向量的维度。
        # self.pe: 使用nn.Embedding创建了一个嵌入层，其词汇表大小为max_len（即每个位置是一个“词”），嵌入维度为d_model。
        self.pe = nn.Embedding(max_len, d_model)
        # 应用一个权重初始化方法_init_weights到模型的所有模块上。
        self.apply(self._init_weights)
    # 接受一个参数x，代表输入的序列
    def forward(self, x):
        # 来获取输入张量 x 的第一个维度的大小，即批次大小（batch size）。
        batch_size = x.size(0)
        # 这行代码首先从嵌入层self.pe中获取权重（即位置嵌入向量）。
        # 然后，它增加一个维度（通过unsqueeze(0)），使得权重张量的形状从[max_len, d_model]变为[1, max_len, d_model]。
        # 最后，它使用repeat方法将这个张量复制batch_size次，
        # 使得其形状变为[batch_size, max_len, d_model]。这样，每个样本在批次中都会得到相同的位置嵌入。
        return self.pe.weight.unsqueeze(0).repeat(batch_size, 1, 1)

    # 这是_init_weights方法的一个可能实现，它用于初始化nn.Embedding层的权重。
    # 在PositionalEmbedding类的__init__方法中，self.apply(self._init_weights)会调用这个方法，
    # 以应用权重初始化到所有子模块上。
    # 该方法接受一个参数module，它代表模型中的一个子模块。
    def _init_weights(self, module):
        """Initialize the weights."""
        # 检查module是否是nn.Embedding的实例。如果是，就执行下面的权重初始化操作。
        if isinstance(module, nn.Embedding):
            # 使用正态分布（均值为0，标准差为0.02）来初始化嵌入层的权重。
            # normal_是一个原地操作（in-place operation），它会直接修改
            module.weight.data.normal_(mean=0.0, std=0.02)
            # 检查嵌入层是否有一个填充索引（padding index）。如果有，执行下面的操作。
            if module.padding_idx is not None:
                # 将填充索引对应的权重设置为0。这通常用于处理序列填充，确保模型不会从填充位置学习任何信息。
                module.weight.data[module.padding_idx].zero_()

"BERT模型中的两种嵌入方式：TokenEmbedding（词嵌入）和PositionalEmbedding（位置嵌入）。"
"在BERT（Bidirectional Encoder Representations from Transformers）模型中，"
"这两种嵌入通常被相加，以捕获词汇信息和序列中单词的位置信息。"
"词嵌入和位置嵌入embedding"
class BERTEmbedding(nn.Module):
    """
    BERT Embedding which is consisted with under features
        1. TokenEmbedding : normal embedding matrix
        2. PositionalEmbedding : adding positional information using sin, cos
        sum of all these features are output of BERTEmbedding
    """
    def __init__(self, vocab_size, embed_size, max_len, dropout=0.1):
        """
        :param vocab_size: total vocab size
        :param embed_size: embedding size of token embedding
        :param dropout: dropout rate
        """
        # vocab_size: 词汇表的大小，即嵌入矩阵的行数。
        # embed_size: 嵌入向量的维度。
        # max_len: 序列的最大长度，用于位置嵌入。
        # dropout: dropout的比率，用于防止过拟合。
        super().__init__()
        # 使用nn.Embedding创建了一个词嵌入层 ;padding_idx=0，表示索引0为填充索引
        self.token = nn.Embedding(num_embeddings=vocab_size, embedding_dim=embed_size, padding_idx=0)
        # 创建了一个PositionalEmbedding对象，用于生成位置嵌入。
        self.position = PositionalEmbedding(max_len=max_len, d_model=embed_size)
        # 创建了一个dropout层，用于在训练过程中随机丢弃一部分神经元的输出
        self.dropout = nn.Dropout(p=dropout)
        #  存储嵌入向量的维度，方便后续使用
        self.embed_size = embed_size
        # 初始化模型的所有模块权重
        self.apply(self._init_weights)

    # 定义了输入数据sequence（通常是token IDs的序列）通过模型时的计算流程。
    # 这里，sequence首先通过self.token（词嵌入层）得到词嵌入，
    # 然后加上通过self.position（位置嵌入层）得到的位置嵌入。
    # 最后，应用self.dropout（dropout层）并返回结果。
    def forward(self, sequence):
        x = self.token(sequence) + self.position(sequence)
        return self.dropout(x)
    "在forward方法中"
    "假设self.position(sequence)能够返回一个与self.token(sequence)形状相同的张量，以便可以直接相加。"
    "这取决于PositionalEmbedding类的实现，可能需要确保它接受序列长度并返回与序列长度相匹配的位置嵌入."

    # 正太分布初始化嵌入层矩阵
    def _init_weights(self, module):
        """Initialize the weights."""
        if isinstance(module, nn.Embedding):
            module.weight.data.normal_(mean=0.0, std=0.02)
            if module.padding_idx is not None:
                module.weight.data[module.padding_idx].zero_()

"词嵌入embedding"
class SimpleEmbedding(nn.Module):
    """
    BERT Embedding which is consisted with under features
        1. TokenEmbedding : normal embedding matrix
    """
    def __init__(self, vocab_size, embed_size, dropout=0.1):
        """
        :param vocab_size: total vocab size
        :param embed_size: embedding size of token embedding
        :param dropout: dropout rate
        """
        super().__init__()
        self.token = nn.Embedding(num_embeddings=vocab_size, embedding_dim=embed_size, padding_idx=0)
        self.dropout = nn.Dropout(p=dropout)
        self.embed_size = embed_size
        self.apply(self._init_weights)

    # 定义了输入数据sequence（通常是token IDs的序列）通过模型时的计算流程。
    # 这里，sequence通过self.token（词嵌入层）得到词嵌入x，然后应用self.dropout（dropout层）并返回结果
    def forward(self, sequence):
        x = self.token(sequence)
        return self.dropout(x)

    # 正态分布初始化模型权重
    def _init_weights(self, module):
        """Initialize the weights."""
        if isinstance(module, nn.Embedding):
            module.weight.data.normal_(mean=0.0, std=0.02)
            if module.padding_idx is not None:
                module.weight.data[module.padding_idx].zero_()