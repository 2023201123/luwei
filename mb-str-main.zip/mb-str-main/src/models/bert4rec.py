
import torch
from torch import nn as nn
import pytorch_lightning as pl
from src.models.embedding import BERTEmbedding, SimpleEmbedding
from src.models.new_transformer import TransformerBlock


class BERT(pl.LightningModule):
    def __init__(self,
        max_len: int = None,
        num_items: int = None,
        n_layer: int = None,
        n_head: int = None,
        n_b: int = None,
        d_model: int = None,
        dropout: float = .0,
        battn: bool = None,
        bpff: bool = None,
        brpb: bool = None, 
    ):
        # max_len: 序列的最大长度（可能用于位置嵌入）。
        # num_items: 词汇表大小（不包括填充和掩码）。
        # n_layer: Transformer层的数量。
        # n_head: 每个Transformer层中自注意力机制的头数。
        # n_b: 可能与相对位置偏差有关，但具体作用需要查看TransformerBlock的实现。
        # d_model: 嵌入向量和Transformer层的维度。
        # dropout: dropout比率。
        # battn: 是否使用某种注意力机制（具体含义不明确，需要查看TransformerBlock的实现）。
        # bpff: 另一个布尔标志，可能与Transformer块中的某种特性有关。
        # brpb: 是否使用行为相关的位置偏差（Behavioral Relative Positional Bias）。

        # 存储传入的参数值。
        # self.d_model, self.num_items, self.n_b, self.battn, self.bpff, self.brpb
        super().__init__()
        self.d_model = d_model
        self.num_items = num_items
        self.n_b = n_b
        self.battn = battn
        self.bpff = bpff
        self.brpb = brpb
        
        vocab_size = num_items + 1 + n_b # add padding and mask 
        # if self.brpb:
        # if True:是一个硬编码的条件，它意味着始终使用SimpleEmbedding，而BERTEmbedding永远不会被使用
        if True:
            # simple embedding, adding behavioral relative positional bias in transformer blocks
            self.embedding = SimpleEmbedding(vocab_size=vocab_size, embed_size=d_model, dropout=dropout)
        else:
            # embedding for BERT, sum of positional, token embeddings  含位置嵌入的BERT嵌入
            self.embedding = BERTEmbedding(vocab_size=vocab_size, embed_size=d_model, max_len=max_len, dropout=dropout)
        # multi-layers transformer blocks
        # self.transformer_blocks是一个nn.ModuleList，包含n_layer个TransformerBlock实例。
        self.transformer_blocks = nn.ModuleList(
            [TransformerBlock(d_model, n_head, d_model * 4, n_b, battn, bpff, brpb, dropout,num_routing_iterations=3) for _ in range(n_layer)])
    # forward方法定义了模型的前向传播过程：
    def forward(self, x, b_seq):
        # 根据输入x生成一个padding掩码mask。
        # get padding masks
        mask = (x > 0)
        # embedding the indexed sequence to sequence of vectors
        # 将输入x通过嵌入层得到嵌入向量。
        x = self.embedding(x)
        # running over multiple transformer blocks
        # 将嵌入向量x和b_seq（行为类型信息）以及mask一起传递给每个Transformer块。
        for transformer in self.transformer_blocks:
            x = transformer.forward(x, b_seq, mask)
        return x

    # 这段代码定义了一个处理流程，其中输入数据首先通过嵌入层进行转换，
    # 然后经过多个Transformer块进行进一步的处理，最终返回处理后的嵌入向量