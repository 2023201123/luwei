

from torch import nn as nn
import torch.nn.functional as F
import torch
import math
from src.models.utils import SublayerConnection, BehaviorSpecificPFF
from src.models.relative_position import RelativePositionBias

"定义了一个名为Attention的模块了"
"1、初始化函数init  接受一个参数dropout=0.1（正则化技术，有助于防止模型过拟合），使用nn.Dropout创建一个dropout层，防止过拟合，随机将一部分输入单元置为0"
class Attention(nn.Module):
    def __init__(self, dropout=0.1):
        super().__init__()
        self.dropout = nn.Dropout(dropout)
    "这个函数实现了注意力机制的核心计算。它接收多个参数，包括query、key、value以及一系列可选参数。"
    def forward(self, query, key, value, b_mat=None, rpb=None, W1=None, alpha1=None, W2=None, alpha2=None, mask=None):
        # 1. Calculate Q-K similarity. w. / w.o. multi-behavior dependencies
        # 1.计算Q-K相似度 行为相似度。query和key之间的相似度计算通常用于确定value的权重
        # 模型在计算注意力分数时考虑了用户或项目的多个行为。
        if b_mat is not None:
            # torch.einsum（被用于计算复杂的点积操作）来计算W1_，其中W1和alpha1经过softmax操作后的结果相乘。
            W1_ = torch.einsum('Bhmn,CBh->Chmn', W1, F.softmax(alpha1, 1))
            # 使用torch.einsum计算att_all，这是query、W1_和key之间的某种形式的点积
            att_all = torch.einsum('bhim,Chmn,bhjn->bhijC', query, W1_, key)
            h=W1.size(1)

            # 使用gather函数和b_mat从att_all中选择特定的元素，然后除以query的最后一个维度的平方根，并加上rpb
            scores = att_all.gather(4, b_mat[:,None,:,:,None].repeat(1,h,1,1,1)).squeeze(4) \
                / math.sqrt(query.size(-1)) + rpb
        else:
            # 则使用简单的矩阵乘法来计算query和key之间的相似度，并同样地除以query的最后一个维度的平方根，并加上rpb。
            scores = torch.matmul(query, key.transpose(-2, -1)) \
                / math.sqrt(query.size(-1)) + rpb


        # 2. dealing with padding and softmax.
        "这段代码确保了注意力机制能够正确处理填充值，并且使用softmax函数来产生有效的概率分布作为注意力权重。"
        "同时，通过dropout来正则化模型，提高泛化能力。"
        # 检查是否存在一个mask。在序列处理中，由于不同序列的长度可能不同，
        # 通常会使用填充（padding）来使所有序列具有相同的长度。
        # mask用于标识哪些位置是实际的序列内容，哪些位置是填充值。
        if mask is not None:
            # 确保mask具有正确的形状。这里假设mask是一个二维张量，通常表示batch中的每个序列的哪些位置是有效的
            assert len(mask.shape) == 2
            # 通常用于处理二维的query和key，确保mask能够正确应用到每个位置。
            mask = (mask[:,:,None] & mask[:,None,:]).unsqueeze(1)
            # 使用masked_fill函数将mask中为0的位置（即填充位置）的分数设置为一个非常小的值。
            # 这确保了这些位置在后续的softmax操作中几乎不会有影响。对于torch.float16类型的分数，
            # 使用了-65500这个特定的值，因为float16类型（半精度浮点数）的数值范围有限，
            # 需要选择一个在该范围内合适的较小值。对于其他类型，使用了-1e30。
            if scores.dtype == torch.float16:
                scores = scores.masked_fill(mask == 0, -65500)
            else:
                scores = scores.masked_fill(mask == 0, -1e30)

        #         应用softmax
        # 对处理过的scores应用softmax函数，以计算注意力权重
        dim = -1
        # 表示softmax是在最后一个维度上应用的，这通常是针对每个query - key对的。
        # 之后，通过dropout层来随机地置零一部分注意力权重，以防止过拟合。
        # 包含了归一化后的注意力权重，这些权重可以用于后续计算加权平均值，从而得到最终的注意力输出。
        p_attn = self.dropout(nn.functional.softmax(scores, dim=-1))

        # 3. information agregation. w./w.o. multi-behavior dependencies
        # 这段代码实现了两种不同方式的信息聚合：
        # 一种是考虑了多行为依赖的复杂聚合方式，另一种是不考虑多行为依赖的简单矩阵乘法方式。
        # 通过b_mat的存在与否来决定使用哪种方式。
        # 这种方式的设计使得模型可以灵活地处理不同的场景，根据具体任务需求来选择是否考虑多行为依赖。
        if b_mat is not None:
            # 获取W2张量的第二个维度的大小，并存储在变量h中。这个维度的大小在后续计算中用作重复次数的参考。
            h=W2.size(1)
            # 对b_mat进行one-hot编码，使其成为一个one-hot张量。num_classes参数指定了one-hot编码的类别数，即alpha2的第一个维度的大小。
            # 之后，使用repeat函数在指定的维度上重复张量，以适应后续计算的形状要求。
            one_hot_b_mat = F.one_hot(b_mat[:,None,:,:], num_classes=alpha2.size(0)).repeat(1,h,1,1,1)
            # 使用torch.einsum函数计算W2_。
            # 这里，W2和经过softmax处理的alpha2进行某种形式的点积运算，结果存储在W2_中。
            W2_ = torch.einsum('BhdD,CBh->ChdD', W2, F.softmax(alpha2, 1))
            # 最后，使用torch.einsum函数进行信息聚合。
            # 这里将注意力权重p_attn、one-hot编码的b_mat（one_hot_b_mat）、W2_和value进行复杂的点积运算，
            # ]得到最终的聚合结果。这个计算考虑了多行为依赖，通过b_mat和W2_的交互来实现。
            return torch.einsum('bhij, bhijC, ChdD, bhjd -> bhiD', p_attn, one_hot_b_mat, W2_, value)
            # return torch.matmul(p_attn, value)
        else:
            # 如果b_mat为None，代码将简单地使用矩阵乘法将注意力权重p_attn和value相乘，
            # 得到聚合后的结果。这种情况下，没有考虑多行为依赖。
            return torch.matmul(p_attn, value)

class MultiHeadedAttention(nn.Module):
    def __init__(self, h, n_b, battn, brpb,  d_model, dropout=0.1,
                 ):
        super(MultiHeadedAttention,self).__init__()
        assert d_model % h == 0  #d：hidden_size可以被 h：n_heads整除

        # We assume d_v always equals d_k
        self.d_k = d_model // h
        self.h = h  #多头的头
        self.n_b = n_b  #行为类型
        self.battn = battn
        self.brpb = brpb
        
        if battn and n_b > 1: # behavior-specific mutual attention
            self.W1 = nn.Parameter(torch.randn(self.n_b, self.h, self.d_k, self.d_k))
            self.alpha1 = nn.Parameter(torch.randn(self.n_b * self.n_b + 1, self.n_b, self.h))
            self.W2 = nn.Parameter(torch.randn(self.n_b, self.h, self.d_k, self.d_k))
            self.alpha2 = nn.Parameter(torch.randn(self.n_b * self.n_b + 1, self.n_b, self.h))
            self.linear_layers = nn.Parameter(torch.randn(3, self.n_b+1, d_model, self.h, self.d_k))
        else:
            self.W1 = None
            self.W2 = None
            self.alpha1, self.alpha2 = None, None
            self.linear_layers = nn.Parameter(torch.randn(3, d_model, self.h, self.d_k))
        self.linear_layers.data.normal_(mean=0.0, std=0.02)

        if self.brpb:
            self.rpb = nn.ModuleList([RelativePositionBias(32,40,self.h) for i in range(self.n_b * self.n_b + 1)])
        self.attention = Attention(dropout)
        self.dropout = nn.Dropout(dropout)
    
    def forward(self, query, key, value, b_seq=None, mask=None):
        batch_size, seq_len = query.size(0), query.size(1)
        b_mat = ((b_seq[:,:,None]-1)*self.n_b + b_seq[:,None,:]) * (b_seq[:,:,None]*b_seq[:,None,:]!=0)
        # 0. rel pos bias
        if self.brpb:
            rel_pos_bias = torch.stack([layer(seq_len, seq_len) for layer in self.rpb], -1).repeat(batch_size,1,1,1,1)
            rel_pos_bias = rel_pos_bias.gather(4, b_mat[:,None,:,:,None].repeat(1,self.h,1,1,1)).squeeze(4)
        else:
            rel_pos_bias = 0
        
        if self.battn and self.n_b>1: # behavior-specific mutual attention
            # 1) Do all the linear projections in batch from d_model => h x d_k
            query, key, value = [torch.einsum("bnd, Bdhk, bnB->bhnk", x, self.linear_layers[l], F.one_hot(b_seq,num_classes=self.n_b+1).float())
                             for l, x in zip(range(3), (query, key, value))]
        else:
            # 1) Do all the linear projections in batch from d_model => h x d_k
            query, key, value = [torch.einsum("bnd, dhk->bhnk", x, self.linear_layers[l])
                             for l, x in zip(range(3), (query, key, value))]
            b_mat = None

        # 2) Apply attention on all the projected vectors in batch.
        x = self.attention(query, key, value, b_mat=b_mat, rpb=rel_pos_bias, W1=self.W1, alpha1=self.alpha1, W2=self.W2, alpha2=self.alpha2, mask=mask)

        # 3) "Concat" using a view.
        x = x.transpose(1, 2).contiguous().view(batch_size, -1, self.h * self.d_k)

        return x



class TransformerBlock(nn.Module):
    def __init__(self, hidden, attn_heads, feed_forward_hidden, n_b, battn, bpff, brpb, dropout,num_routing_iterations):
        """
        :param hidden: hidden size of transformer
        :param attn_heads: head sizes of multi-head attention
        :param feed_forward_hidden: feed_forward_hidden, usually 4*hidden_size
        :param dropout: dropout rate
        :param n_b: number of behaviors
        :param battn: use multi-behavior cross attention
        :param bpff: use behavior-specific multi-gated mixture of experts
        :param brpb: use behavior-specific relative position bias
        """
        super().__init__()
        # 前面
        # self.conv1 = nn.Conv1d(in_channels=hidden, out_channels=feed_forward_hidden, kernel_size=1)
        # self.conv2 = nn.Conv1d(in_channels=feed_forward_hidden, out_channels=hidden, kernel_size=1)
        self.attention = MultiHeadedAttention(h=attn_heads, n_b=n_b, battn=battn, brpb=brpb, d_model=hidden, dropout=dropout)
        self.conv1 = nn.Conv1d(in_channels=hidden, out_channels=feed_forward_hidden, kernel_size=1)
        self.conv2 = nn.Conv1d(in_channels=feed_forward_hidden, out_channels=hidden, kernel_size=1)
        self.feed_forward = BehaviorSpecificPFF(d_model=hidden, d_ff=feed_forward_hidden, n_b=n_b, bpff=bpff, dropout=dropout)
        self.input_sublayer = SublayerConnection(size=hidden, dropout=dropout)
        self.output_sublayer = SublayerConnection(size=hidden, dropout=dropout)
        self.dropout = nn.Dropout(p=dropout)


    def forward(self, x, b_seq, mask):
        x = self.input_sublayer(x, lambda _x: self.attention(_x, _x, _x, b_seq, mask=mask))
        x = self.capsule_layer(x)
        x = self.output_sublayer(x, lambda _x: self.feed_forward(_x, b_seq))
        return self.dropout(x)