import os
import logging
import torch
import torch.nn as nn
import numpy as np
import torch.nn.functional as F

class MultiInterestExtractor(nn.Moudle):
    def __init__(self,k,):
        self.k = k