
from src.models.bert4rec import BERT
from src.models.heads import DotProductPredictionHead, CGCDotProductPredictionHead