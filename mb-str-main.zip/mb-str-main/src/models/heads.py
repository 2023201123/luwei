

import torch
import torch.nn as nn
import torch.nn.functional as F

# head used for bert4rec
# 它是BERT4Rec推荐系统中的预测头部分。
# BERT4Rec是一种基于BERT的序列推荐模型。
# 在这个预测头中，它使用了点积（Dot Product）来计算用户和物品之间的相似度。

"这个模型可以用于根据用户的嵌入向量（或其他上下文信息）来预测用户对一系列候选项目的偏好或得分。"
"它使用点积来计算相似度，并通过一个线性层和ReLU激活函数对输入嵌入进行转换。"
"偏置项用于调整每个项目的预测得分。在推荐系统中，这些得分可以用于排序和选择最相关的项目来展示给用户。"
class DotProductPredictionHead(nn.Module):
    """share embedding parameters"""
    # d_model: 输入的嵌入维度。
    # num_items: 候选项目的数量。
    # token_embeddings: 一个预先定义的嵌入层，用于将候选项目转换为嵌入向量。
    def __init__(self, d_model, num_items, token_embeddings):
        super().__init__()
        self.token_embeddings = token_embeddings
        # self.vocab_size 设置为候选项目的数量加一（可能是为了包含特殊的填充或未知标记）。
        # self.out 是一个简单的线性层，后面跟着一个ReLU激活函数。
        self.vocab_size = num_items + 1
        self.out = nn.Sequential(
                nn.Linear(d_model, d_model),
                nn.ReLU(),
            )
        # self.bias 是一个可学习的偏置项，其形状为 (1, vocab_size)。
        self.bias = nn.Parameter(torch.zeros(1, self.vocab_size))

    def forward(self, x, b_seq, candidates=None):
        x = self.out(x)  # B x H or M x H
        # 使用token_embeddings将candidates转换为嵌入向量。
        # 通过点积计算x与每个候选嵌入向量之间的相似度，得到logits。
        # 使用gather操作从self.bias中获取与candidates对应的偏置项，并将其加到logits上。
        if candidates is not None:  # x : B x H
            emb = self.token_embeddings(candidates)  # B x C x H
            logits = (x.unsqueeze(1) * emb).sum(-1)  # B x C
            bias = self.bias.expand(logits.size(0), -1).gather(1, candidates)  # B x C
            logits += bias
        # 使用token_embeddings.weight（即嵌入层的权重）来获取所有可能项目的嵌入向量。
        # 通过矩阵乘法计算x与所有嵌入向量之间的得分，得到logits。
        # 将self.bias加到logits上。
        else:  # x : M x H
            emb = self.token_embeddings.weight[:self.vocab_size]  # V x H
            logits = torch.matmul(x, emb.transpose(0, 1))  # M x V
            logits += self.bias
        return logits


class CGCDotProductPredictionHead(nn.Module):
    """
    model with shared expert and behavior specific expert
    3 shared expert,
    1 specific expert per behavior.
    """
    """"
    d_model：模型的维度，即嵌入向量的大小。
    n_b：行为的数量。
    n_e_sh：共享专家的数量。
    n_e_sp：每个行为特定的专家的数量。
    num_items：项目或候选物的数量。
    token_embeddings：用于将候选物转换为嵌入向量的嵌入层。
    """
    def __init__(self, d_model, n_b, n_e_sh, n_e_sp, num_items, token_embeddings):
        super().__init__()
        self.n_b = n_b
        self.n_e_sh = n_e_sh
        self.n_e_sp = n_e_sp
        self.vocab_size = num_items + 1
        self.softmax = nn.Softmax(dim=-1)
        """"
        共享专家（shared_experts）：一组线性层，用于处理所有行为的共享特征。
        特定行为专家（specific_experts）：另一组线性层，每个行为有一个或多个这样的专家，用于处理特定于该行为的特征。
        门控机制（w_gates）：一个可学习的参数张量，用于确定每个专家对最终输出的贡献。
        嵌入层（token_embeddings）：用于将候选物ID转换为嵌入向量。
        """
        self.shared_experts = nn.ModuleList([nn.Sequential(nn.Linear(d_model, d_model)) for i in range(self.n_e_sh)])
        self.specific_experts = nn.ModuleList([nn.Sequential(nn.Linear(d_model, d_model)) for i in range(self.n_b * self.n_e_sp)])
        # self.shared_experts = nn.ModuleList([nn.Sequential(nn.Linear(d_model, d_model), nn.ReLU(),nn.Linear(d_model, d_model)) for i in range(self.n_e_sh)])
        # self.specific_experts = nn.ModuleList([nn.Sequential(nn.Linear(d_model, d_model), nn.ReLU(),nn.Linear(d_model, d_model)) for i in range(self.n_b * self.n_e_sp)])
        self.w_gates = nn.Parameter(torch.randn(self.n_b, d_model, self.n_e_sh + self.n_e_sp), requires_grad=True)
        self.token_embeddings = token_embeddings
        self.ln = nn.LayerNorm(d_model)

    def forward(self, x, b_seq, candidates=None):
        x = self.mmoe_process(x, b_seq)
        if candidates is not None:  # x : B x H ； 批量大小 x 特征维度
            emb = self.token_embeddings(candidates)  # B x C x H
            logits = (x.unsqueeze(1) * emb).sum(-1)  # B x C
        else:  # x : M x H
            # candidates：
            # 可选参数，表示候选物的ID。如果提供，则模型会对这些候选物进行评分；
            # 否则，它会使用所有可能的候选物（例如，整个词汇表）。
            emb = self.token_embeddings.weight[:self.vocab_size]  # V x H
            logits = torch.matmul(x, emb.transpose(0, 1))  # M x V
        return logits

    #    关键部分，它实现了多门控混合专家（MMoE）结构的核心计算逻辑。
    #    MMoE旨在通过多个共享和特定于任务的专家网络，以及一个门控网络，来联合学习多个任务的共享表示和特定表示。
    def mmoe_process(self, x, b_seq):
        shared_experts_o = [e(x) for e in self.shared_experts]
        specific_experts_o = [e(x) for e in self.specific_experts]
        # 分别通过所有共享专家和特定专家对输入x进行前向传播，并收集输出结果。
        gates_o = self.softmax(torch.einsum('nd,tde->tne', x, self.w_gates))
        # 使用torch.einsum进行张量乘法，将输入x和门控参数w_gates相乘，然后通过softmax函数得到每个专家的门控权重。
        # 这里的einsum操作允许我们以灵活的方式指定多维张量的乘法操作。

        # rearange
        # 将共享专家和特定专家的输出重新排列成一个四维张量experts_o_tensor，其形状为[任务数量, 专家数量, 批量大小, 特征维度]。
        # 这允许我们在后续步骤中根据任务（或行为）来聚合专家输出。
        experts_o_tensor = torch.stack([torch.stack(shared_experts_o+specific_experts_o[i*self.n_e_sp:(i+1)*self.n_e_sp]) for i in range(self.n_b)])
        # torch.stack([torch.stack(shared_experts_o+specific_experts_o[i*2: (i+1)*2]) for i in range(4)])
        output = torch.einsum('tend,tne->tnd', experts_o_tensor, gates_o)
        # 使用einsum再次根据门控权重gates_o对专家输出experts_o_tensor进行加权聚合，得到每个任务的聚合输出。

        # 最终输出：这行代码将原始输入x（零扩展后的）和聚合后的输出output连接起来。
        # 这样做可能是为了保持输出的维度与原始输入一致，或者为了方便后续与行为序列b_seq进行交互。
        outputs = torch.cat([torch.zeros_like(x).unsqueeze(0), output])

        # 首先，使用F.one_hot将行为序列b_seq转换为一热编码（one-hot encoding）。
        # 然后，通过einsum操作将outputs与一热编码相乘，从而根据行为序列选择相应的输出。
        # 最后，通过层归一化self.ln并加上原始输入x，得到最终的输出。
        return x + self.ln(torch.einsum('tnd, nt -> nd', outputs, F.one_hot(b_seq, num_classes=self.n_b+1).float()))

# class DotProductPredictionHead(nn.Module):
#     """share embedding parameters"""
#     def __init__(self, d_model, num_items, token_embeddings):
#         super().__init__()
#         self.token_embeddings = token_embeddings
#         self.vocab_size = num_items + 1

#     def forward(self, x, b_seq, candidates=None):
#         if candidates is not None:  # x : B x H
#             emb = self.token_embeddings(candidates)  # B x C x H
#             logits = (x.unsqueeze(1) * emb).sum(-1)  # B x C
#         else:  # x : M x H
#             emb = self.token_embeddings.weight[:self.vocab_size]  # V x H
#             logits = torch.matmul(x, emb.transpose(0, 1))  # M x V
#         return logits