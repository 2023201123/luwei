
import torch
import pytorch_lightning as pl
from src.models.heads import CGCDotProductPredictionHead, DotProductPredictionHead
from src.models.bert4rec import BERT
from src.utils import recalls_and_ndcgs_for_ks


class RecModel(pl.LightningModule):
    def __init__(self,
            backbone: BERT,
            b_head: bool = False,
        ):
        super().__init__()
        self.backbone = backbone
        self.n_b = backbone.n_b
        if b_head:
            # 复杂的，加了共享专家什么的
            self.head = CGCDotProductPredictionHead(backbone.d_model, self.n_b, 3, 1, backbone.num_items, self.backbone.embedding.token)
        else:
            self.head = DotProductPredictionHead(backbone.d_model, backbone.num_items, self.backbone.embedding.token)
        self.loss = torch.nn.CrossEntropyLoss(ignore_index=0)
    #     定义了一个交叉熵损失函数，其中ignore_index=0意味着在计算损失时忽略标签为0的样本。

    # 它接收input_ids和b_seq作为输入，并将它们传递给backbone（BERT模型）进行处理。最后返回BERT的输出。
    def forward(self, input_ids, b_seq):
        return self.backbone(input_ids, b_seq)

    # 定义了模型在单个训练批次上的行为
    def training_step(self, batch, batch_idx):
        """数据提取"""
        input_ids = batch['input_ids']
        b_seq = batch['behaviors']
        """前向传播"""
        outputs = self(input_ids, b_seq)
        # 这行代码调用了模型RecModel（通过self表示）的前向传播方法，并将input_ids和b_seq作为输入，得到输出outputs。
        """输出和标签的处理"""
        outputs = outputs.view(-1, outputs.size(-1))  # BT x H batch_size*seq_len x Hiddening
        labels = batch['labels']
        labels = labels.view(-1)  # BT batch_size*seq_len

        """有效标签的处理"""
        valid = labels>0 #首先检查哪些标签是有效的（即大于0） 将有效的标签赋值给valid
        valid_index = valid.nonzero().squeeze()  # M
        # 获取valid张量中非零元素的索引，并将这些索引存储在一维张量valid_index中。
        """获取有效输出和标签"""
        valid_outputs = outputs[valid_index] #使用valid_index从outputs中选择有效的输出。
        valid_b_seq = b_seq.view(-1)[valid_index] # M   首先展平b_seq，然后使用valid_index选择有效的行为序列。
        valid_labels = labels[valid_index]
        valid_logits = self.head(valid_outputs, valid_b_seq) # M

        loss = self.loss(valid_logits, valid_labels)
        loss = loss.unsqueeze(0)
        return {'loss':loss}


    def training_epoch_end(self, training_step_outputs):
        loss = torch.cat([o['loss'] for o in training_step_outputs], 0).mean()
        self.log('train_loss', loss)

    def validation_step(self, batch, batch_idx):
        input_ids = batch['input_ids']
        b_seq = batch['behaviors']
        outputs = self(input_ids, b_seq)

        # get scores (B x C) for evaluation
        last_outputs = outputs[:, -1, :]
        last_b_seq = b_seq[:,-1]
        candidates = batch['candidates'].squeeze() # B x C
        logits = self.head(last_outputs, last_b_seq, candidates)
        labels = batch['labels'].squeeze()
        metrics = recalls_and_ndcgs_for_ks(logits, labels, [1, 5, 10, 20, 50])

        return metrics

    def validation_epoch_end(self, validation_step_outputs):
        keys = validation_step_outputs[0].keys()
        for k in keys:
            tmp = []
            for o in validation_step_outputs:
                tmp.append(o[k])
            self.log(f'Val:{k}', torch.Tensor(tmp).mean())